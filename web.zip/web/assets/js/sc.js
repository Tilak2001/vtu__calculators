  // $(document).ready(function() {
//   let $carouselItems = $('.item');
//   let $indicators = $('.indicators button');
//   let currentIndex = 0;
//   let slideInterval;

//   // Function to show the slide based on the index
//   function showSlide(index) {
//     $carouselItems.removeClass('active');  // Remove 'active' from all slides
//     $indicators.removeClass('active');  // Remove 'active' from all indicators

//     // Fade in the current slide and show the active indicator
//     $carouselItems.eq(index).addClass('active');
//     $indicators.eq(index).addClass('active');
//   }

//   // Indicator click event
//   $indicators.on('click', function() {
//     currentIndex = $(this).data('slide-to');
//     showSlide(currentIndex);
//   });

//   // Auto slide functionality
//   function nextSlide() {
//     currentIndex = (currentIndex + 1) % $carouselItems.length;
//     showSlide(currentIndex);
//   }

//   // Set interval for automatic slide change every 5 seconds
//   slideInterval = setInterval(nextSlide, 5000);

//   // Pause the auto slide when hovering over the carousel
//   $('.carousel').hover(function() {
//     clearInterval(slideInterval);
//   }, function() {
//     slideInterval = setInterval(nextSlide, 5000);
//   });

//   // Show the initial slide
//   showSlide(currentIndex);
// });



// $(document).ready(function() {
//   let $carouselItems = $('.text-wrapper'); 
//   let $indicators = $('.indicators button');
//   let currentIndex = 0;
//   let slideInterval;
//   function showSlide(index) {
  
//     $carouselItems.removeClass('active');
//     $indicators.removeClass('active');
//     $carouselItems.eq(index).addClass('active');
//     $indicators.eq(index).addClass('active');

  
//     $('.inner').css('transform', 'translateX(' + (-index * 100) + '%)');
//   }


//   $indicators.on('click', function() {
//     currentIndex = $(this).data('slide-to');
//     showSlide(currentIndex);
//   });


//   function nextSlide() {
//     currentIndex = (currentIndex + 1) % $carouselItems.length;
//     showSlide(currentIndex);
//   }

//   slideInterval = setInterval(nextSlide, 5000);

//   $('.carousel').hover(function() {
//     clearInterval(slideInterval);
//   }, function() {
//     slideInterval = setInterval(nextSlide, 5000);
//   });

//   showSlide(currentIndex);
// });


// $(document).ready(function () {

//   var $navLinks = $('nav a');
//   var $sections = $('section');


//   $(window).on('scroll', function () {
//       var scrollPos = $(document).scrollTop();

//       $sections.each(function () {
//           var $currentSection = $(this);
//           var sectionTop = $currentSection;
//           var sectionBottom = sectionTop + $currentSection.outerHeight();

//           if (scrollPos >= sectionTop && scrollPos < sectionBottom) {
//               var id = $currentSection.attr('id');
//               $navLinks.removeClass('active');
//               $('a[href="#' + id + '"]').addClass('active');
//           }
//       });
//   });
// });


// $(document).ready(function(){
//   $('.nav-link').on('click',function(){
//     $('.nav-link').removeClass('active');
//     $(this).addClass('active');
//   });
// });

// $sections.each(function () {
//   var $currentSection = $(this);
//   var sectionTop = $currentSection;
//   var sectionBottom = sectionTop + $currentSection.outerHeight();

//   if (scrollPos >= sectionTop && scrollPos < sectionBottom) {
//       var id = $currentSection.attr('id');
//       $navLinks.removeClass('active');
//       $('a[href="#' + id + '"]').addClass('active');
//   }
// });


//   // Function to handle click event on nav links
//   $navLinks.on('click', function () {
//       $navLinks.removeClass('active'); // Remove active class from all links
//       $(this).addClass('active'); // Add active class to the clicked link
//   });
// });

// $(document).ready(function () {
//   var $navLinks = $('nav a');
//   var $sections = $('section');

//   // Function to handle the scroll event
//   $(window).on('scroll', function () {
//       var scrollPos = $(document).scrollTop(); // Get current scroll position

//       $sections.each(function () {
//           var $currentSection = $(this);
//           var sectionTop = $currentSection.offset().top; // Top of the section
//           var sectionBottom = sectionTop + $currentSection.outerHeight(); // Bottom of the section

//           // Check if the section is in the viewport (even partially)
//           if (scrollPos + $(window).height() > sectionTop && scrollPos < sectionBottom) {
//               var id = $currentSection.attr('id'); // Get the section's ID
//               $navLinks.removeClass('active'); // Remove active class from all links
//               $('a[href="#' + id + '"]').addClass('active'); // Add active class to the current link
//           }
//       });
//   });

//   // Function to handle the click event on nav links
//   $navLinks.on('click', function (e) {
//       e.preventDefault(); // Prevent default anchor link behavior

//       var targetId = $(this).attr('href'); // Get the href value (section ID)
//       var $targetSection = $(targetId); // Find the target section

//       // Scroll to the target section smoothly
//       $('html, body').animate({
//           scrollTop: $targetSection.offset().top // Scroll to the target section
//       }, 500); // 500ms smooth scroll duration

//       // Remove active class from all links and add to the clicked link
//       $navLinks.removeClass('active');
//       $(this).addClass('active');
//   });
// });



$(document).ready(function () {
  var $navLinks = $('nav a');
  var $sections = $('section');


  $(window).on('scroll', function () {
      var scrollPos = $(document).scrollTop(); 
      var windowHeight = $(window).height(); 

      $sections.each(function () {
          var $currentSection = $(this);
          var sectionTop = $currentSection.offset().top; 
          var sectionBottom = sectionTop + $currentSection.outerHeight(); 
          var sectionMiddle = sectionTop + ($currentSection.outerHeight() / 2); 

          
          if (scrollPos + windowHeight / 2 >= sectionMiddle && scrollPos + windowHeight / 2 < sectionBottom) {
              var id = $currentSection.attr('id'); 
              $navLinks.removeClass('active'); 
              $('a[href="#' + id + '"]').addClass('active'); 
          }
      });
  });
  $navLinks.on('click', function (e) {
      e.preventDefault(); 

      var targetId = $(this).attr('href');
      var $targetSection = $(targetId); 

      $('html, body').animate({
          scrollTop: $targetSection.offset().top
      }, 500);
      $navLinks.removeClass('active');
      $(this).addClass('active');
  });
});

// $(document).ready(function () {
//   // Function to handle the scroll event and add animation
//   function handleScroll() {
//       $('.basic-box').each(function () {
//           var $this = $(this);
//           var sectionTop = $this.offset().top;
//           var sectionBottom = sectionTop + $this.outerHeight();
//           var windowTop = $(window).scrollTop();
//           var windowBottom = windowTop + $(window).height();

//           // Check if the section is in the viewport
//           if (sectionBottom > windowTop && sectionTop < windowBottom) {
//               // Add the fade-in class to trigger the animation
//               $this.find('img').addClass('fade-in');
//               $this.find('p').addClass('fade-in');
//           }
//       });
//   }

//   // Trigger scroll handler on page load and on scroll event
//   $(window).on('scroll', handleScroll);
  
//   // Trigger on page load
//   handleScroll();
// });


// $(document).ready(function () {
//   // Function to handle the scroll event and add/remove animations
//   function handleScroll() {
//       $('.basic-box').each(function () {
//           var $this = $(this);
//           var sectionTop = $this.offset().top;
//           var sectionBottom = sectionTop + $this.outerHeight();
//           var windowTop = $(window).scrollTop();
//           var windowBottom = windowTop + $(window).height();

//           // Check if the section is in the viewport (visible)
//           if (sectionBottom > windowTop && sectionTop < windowBottom) {
//               // Add the fade-in class to trigger the animation (only if not already applied)
//               $this.find('img').addClass('fade-in');
//               $this.find('p').addClass('fade-in');
//               $this.find('.box').addClass('fade-in');
//           } else {
//               // Remove the fade-in class to reset the element (so it can fade in again on re-entering the viewport)
//               $this.find('img').removeClass('fade-in');
//               $this.find('p').removeClass('fade-in');
//               $this.find('.box').removeClass('fade-in');
//           }
//       });
//   }

//   // Trigger scroll handler on page load and on scroll event
//   $(window).on('scroll', handleScroll);

//   // Trigger on page load to check if any elements are already in view
//   handleScroll();
// });

$(document).ready(function () {
  // Function to handle the scroll event and add/remove animations
  function handleScroll() {
      $('.box').each(function () {
          var $this = $(this);
          var sectionTop = $this.offset().top;
          var sectionBottom = sectionTop + $this.outerHeight();
          var windowTop = $(window).scrollTop();
          var windowBottom = windowTop + $(window).height();

          // Check if the section is in the viewport (visible)
          if (sectionBottom > windowTop && sectionTop < windowBottom) {
              // Add the fade-in class to trigger the animation
              $this.addClass('fade-in'); // Add the fade-in class to box
              $this.find('.box1').addClass('fade-in'); // Add fade-in class to text inside the box
          } else {
              // Remove the fade-in class to reset the element (so it can fade in again on re-entering the viewport)
              $this.removeClass('fade-in');
              $this.find('.box1').removeClass('fade-in');
          }

          if (sectionBottom > windowTop && sectionTop < windowBottom) {
            // Add the fade-in class to trigger the animation
            $this.addClass('fade-in1'); // Add the fade-in class to box
            $this.find('img').addClass('fade-in'); // Add fade-in class to images
            $this.find('p').addClass('fade-in'); // Add fade-in class to text (p)
        } else {
            // Remove the fade-in class to reset the element (so it can fade in again on re-entering the viewport)
            $this.removeClass('fade-in1');
            $this.find('img').removeClass('fade-in');
            $this.find('p').removeClass('fade-in');
        }
          
      });
  }

  // Trigger scroll handler on page load and on scroll event
  $(window).on('scroll', handleScroll);

  // Trigger on page load to check if any elements are already in view
  handleScroll();
});
