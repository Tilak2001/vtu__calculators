﻿using System;

namespace LargestNum
{
    class LargeNo
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the Number of Rows : ");
            int row = int.Parse(Console.ReadLine());

            Console.Write("Enter the Number of Columns : ");
            int col = int.Parse(Console.ReadLine());

            int[,] arr = new int[row, col];
            Console.WriteLine("Enter elements : ");
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < col; j++)
                {
                    Console.Write($"Elements a[{i},{j}] :");
                    arr[i, j] = int.Parse(Console.ReadLine());
                }
            }

            int[] maximumValue = new int[row];
            for (int i = 0; i < row; i++)
            {
                int max = arr[i,0];
                for (int j = 1 ; j < col; j++)
                {
                    if (arr[i, j] > max)
                    {
                        max = arr[i, j];
                    }
                }
                maximumValue[i] = max;
            }
            Console.WriteLine("Maximum Values : " + String.Join(" , ", maximumValue));
        }
    }
}
