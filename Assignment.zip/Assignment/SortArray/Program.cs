﻿using System;

namespace SortArray
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number of elements : ");
            int input = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the elements : ");
            int[] arr = new int[input];
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.Write("The elements are : ");
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write(arr[i] + " ");
            }

            Console.WriteLine();

            int temp = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                for (int j = i + 1; j < arr.Length; j++)
                {
                    if (arr[i] > arr[j])
                    {
                        //temp = arr[i];
                        //arr[i] = arr[j];
                        //arr[j] = temp;
                        arr[i] = arr[i] + arr[j];
                        arr[j] = arr[i] - arr[j];
                        arr[i] = arr[i] - arr[j];
                    }
                }
            }
            Console.WriteLine("Sorting in Ascending order : ");
            for (int i = 0; i < arr.Length; i++)
            {
                if (i < arr.Length - 1)
                    Console.Write(arr[i] + " ");
                else
                    Console.Write(arr[i]);
            }
        }

        static void Sort()
        {
            int[] arr = new int[] { 3, 7, 1, 9, 0, 2, 8, 1 };

            Array.Sort(arr);

            Console.WriteLine("Ascending Order : ");
            foreach (int item in arr)
                Console.Write(arr[item] + " ");

            //Array.Sort(arr);
            Array.Reverse(arr);
            Console.Write("Descending Order : ");
            for (int i = 0; i < arr.Length; i++)
                Console.Write(arr[i] + " ");

            Console.WriteLine();
        }
    }
}
