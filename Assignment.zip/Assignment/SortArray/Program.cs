﻿using System;

namespace SortArray
{
    class Program
    {
        static void Main(string[] args)
        {
            //int[] arr = new int[] { 3, 7, 1, 9, 0, 2, 8, 1 };

            //Array.Sort(arr);
            //Console.Write("Ascending Order : ");
            //for (int i = 0; i < arr.Length; i++)
            //{
            //    Console.Write(arr[i] + " ");
            //}

            //Console.WriteLine();

            //Array.Sort(arr);
            //Array.Reverse(arr);
            //Console.Write("Descending Order : ");
            //for (int i = 0; i < arr.Length; i++)
            //{
            //    Console.Write(arr[i] + " ");
            //}
            ////foreach (int item in arr)
            ////{
            ////    item = item * 2;
            ////    Console.Write(item *2 + " ");
            ////}

            //Console.WriteLine();

            //string input = "Hello";
            //input = "hii";
            ////string input2 = "Hello";
            //Console.WriteLine(input);
            ////Console.WriteLine(input2);


            Console.WriteLine("Enter the number of elements : ");
            int input = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the elements : ");
            int[] arr = new int[input];
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.Write("The elements are : ");
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write(arr[i] + " ");
            }

            Console.WriteLine();

            int temp = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                for (int j = i + 1; j < arr.Length; j++)
                {
                    if (arr[i] > arr[j])
                    {
                        temp = arr[i];
                        arr[i] = arr[j];
                        arr[j] = temp;
                    }
                }
            }
            Console.WriteLine("Sorting in Ascending order : ");
            //foreach (int item in arr)
            //{
            //    Console.Write(item + " ");
            //}
            for(int i = 0;i < arr.Length; i++)
            {
                if (i < arr.Length - 1)
                    Console.Write(arr[i]+" ");
                else
                    Console.Write(arr[i]);
            }
        }
    }
}
