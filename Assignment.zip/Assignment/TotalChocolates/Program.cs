﻿using System;

namespace TotalChocolate
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double money = 50;
            double chocolateCost = 2;
            double chocolatePerWrapper = 0.5;
            int totalChocolates = 0;

            int chocolateBought = (int)(money / chocolateCost);
            totalChocolates += chocolateBought;

            double remainingMoney = money % chocolateCost;
            int wrappers = chocolateBought;

            while (wrappers > 0)
            {
                double cashback = wrappers * chocolatePerWrapper;
                remainingMoney += cashback;
                int newChocolate = (int)(remainingMoney / chocolateCost);

                totalChocolates += newChocolate;
                remainingMoney %= chocolateCost;
                wrappers = newChocolate;
            }
            Console.WriteLine("Total Chocolates : " + totalChocolates);
        }
    }
}
