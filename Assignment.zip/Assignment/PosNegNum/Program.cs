﻿using System;

namespace PosNegNum
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a Number : ");
            int n = Convert.ToInt32(Console.ReadLine());

            if (n > 0)
                Console.WriteLine($"{n} is positive");
            else if (n < 0)
                Console.WriteLine($"{n} is negative");
            else
                Console.WriteLine($"{n} is neutral");
        }
    }
}

