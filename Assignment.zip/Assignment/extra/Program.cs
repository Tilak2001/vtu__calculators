﻿using System;
using System.Linq;

namespace extra
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice = 0;
            while(choice != 7)
            {
                Console.WriteLine("Press 1 for Sorting : ");
                Console.WriteLine("Press 2 for identifying Pos & Neg Number : ");
                Console.WriteLine("Press 3 for Removing Duplicates : ");
                Console.WriteLine("Press 4 for Reversing a String : ");
                Console.WriteLine("Press 5 for Counting the records : ");
                Console.WriteLine("Press 6 for Merging 2 arrays : ");
                Console.WriteLine("Press 7 to Exit!!!");
                Console.WriteLine();
                choice = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine();
                switch (choice)
                {
                    case 1:
                        {
                            Console.WriteLine("Press 1 for Sorting in Asc order : ");
                            Console.WriteLine("Press 2 for Sorting in Desc order : ");
                            int sort = Convert.ToInt32(Console.ReadLine());
                            switch (sort)
                            {
                                case 1:
                                    {
                                        Console.WriteLine("Enter the number of elements : ");
                                        int input = int.Parse(Console.ReadLine());

                                        Console.WriteLine("Enter the elements : ");
                                        int[] arr = new int[input];
                                        for (int i = 0; i < arr.Length; i++)
                                        {
                                            arr[i] = Convert.ToInt32(Console.ReadLine());
                                        }
                                        Console.Write("The elements are : ");
                                        for (int i = 0; i < arr.Length; i++)
                                        {
                                            Console.Write(arr[i] + " ");
                                        }

                                        Console.WriteLine();

                                        int temp = 0;
                                        for (int i = 0; i < arr.Length; i++)
                                        {
                                            for (int j = i + 1; j < arr.Length; j++)
                                            {
                                                if (arr[i] > arr[j])
                                                {
                                                    temp = arr[i];
                                                    arr[i] = arr[j];
                                                    arr[j] = temp;
                                                }
                                            }
                                        }
                                        Console.Write("Ascending Order : ");
                                        for (int i = 0; i < arr.Length; i++)
                                        {
                                            Console.Write(arr[i] + " ");
                                        }
                                        Console.WriteLine();
                                    }
                                    break;
                                case 2:
                                    {
                                        Console.WriteLine("Enter the number of elements : ");
                                        int input = int.Parse(Console.ReadLine());

                                        Console.WriteLine("Enter the elements : ");
                                        int[] arr = new int[input];
                                        for (int i = 0; i < arr.Length; i++)
                                        {
                                            arr[i] = Convert.ToInt32(Console.ReadLine());
                                        }
                                        Console.Write("The elements are : ");
                                        for (int i = 0; i < arr.Length; i++)
                                        {
                                            Console.Write(arr[i] + " ");
                                        }

                                        Console.WriteLine();

                                        int temp = 0;
                                        for (int i = 0; i < arr.Length; i++)
                                        {
                                            for (int j = i + 1; j < arr.Length; j++)
                                            {
                                                if (arr[i] < arr[j])
                                                {
                                                    temp = arr[i];
                                                    arr[i] = arr[j];
                                                    arr[j] = temp;
                                                }
                                            }
                                        }
                                        Console.Write("Descending Order : ");
                                        for (int i = 0; i < arr.Length; i++)
                                        {
                                            Console.Write(arr[i] + " ");
                                        }
                                        Console.WriteLine();
                                    }
                                    break;
                                default:
                                    Console.WriteLine("Invalid Number");
                                    break;
                            }
                        }
                        break;
                    case 2:
                        {
                            Console.Write("Enter a Number : ");
                            int n = Convert.ToInt32(Console.ReadLine());

                            if (n > 0)
                                Console.WriteLine($"{n} is positive");
                            else
                                Console.WriteLine($"{n} is negative");
                            Console.WriteLine();
                        }
                        break;
                    case 3:
                        {
                            Console.Write("Enter a String : ");
                            string remove = Console.ReadLine();

                            string result = "";
                            for (int i = 0; i < remove.Length; i++)
                            {
                                if (!result.Contains(remove[i]))
                                    result += remove[i];
                            }
                            Console.WriteLine($"Updated String : {result}");
                            Console.WriteLine();
                        }
                        break;
                    case 4:
                        {
                            Console.Write("Enter a String : ");
                            String input = Console.ReadLine();
                            string Reverse = "";

                            for (int i = 0; i < input.Length; i++)
                            {
                                Reverse = input[i] + Reverse;
                            }
                            Console.Write("Reversed String : " + Reverse);
                            Console.WriteLine();
                        }
                        break;
                    case 5:
                        {
                            Console.WriteLine("Enter the number of elements : ");
                            int input = int.Parse(Console.ReadLine());

                            Console.WriteLine("Enter the elements : ");
                            int[] arr = new int[input];
                            int totalCount = 0;
                            for (int i = 0; i < arr.Length; i++)
                            {
                                arr[i] = Convert.ToInt32(Console.ReadLine());
                                if (arr[i]>0)
                                    totalCount++;
                            }

                            Console.WriteLine();

                            Console.WriteLine("Total count : " + totalCount);
                            Console.WriteLine();
                        }
                        break;
                    case 6:
                        {
                            Console.WriteLine("Enter the size of array 1 : ");
                            int input = int.Parse(Console.ReadLine());

                            Console.WriteLine();

                            Console.WriteLine("Enter the elements for array 1: ");
                            int[] arr = new int[input];
                            for (int i = 0; i < arr.Length; i++)
                                arr[i] = Convert.ToInt32(Console.ReadLine());

                            Console.WriteLine();

                            Console.WriteLine("Enter the size of array 2 : ");
                            int input1 = int.Parse(Console.ReadLine());

                            Console.WriteLine();

                            Console.WriteLine("Enter the elements for array 2 : ");
                            int[] arr1 = new int[input1];
                            for (int i = 0; i < arr1.Length; i++)
                                arr1[i] = Convert.ToInt32(Console.ReadLine());

                            Console.WriteLine();
                            Console.Write("The elements of array 1 : ");
                            for (int i = 0; i < arr.Length; i++)
                                Console.Write(arr[i] + " ");

                            Console.WriteLine();

                            Console.Write("The elements of array 2 : ");
                            for (int i = 0; i < arr1.Length; i++)
                                Console.Write(arr1[i] + " ");

                            Console.WriteLine();

                            int[] arr2 = new int[arr.Length + arr1.Length];
                            for (int i = 0; i < arr.Length; i++)
                                arr2[i] = arr[i];

                            for (int i = 0; i < arr1.Length; i++)
                                arr2[arr.Length + i] = arr1[i];

                            Console.WriteLine("Merged Array : ");
                            foreach (int item in arr2)
                                Console.Write(item+" ");
                        }
                        break;
                    case 7:
                        Console.WriteLine("You have exited the program !!");
                        break;
                    default:
                        Console.WriteLine("Invalid choice!!");
                        break;
                }
            }
        }
    }
}