﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Enter the operation : ");
        string operation = Console.ReadLine().ToLower();

        Console.Write("Enter the first number : ");
        double firstNumber = Convert.ToDouble(Console.ReadLine());

        Console.Write("Enter the second number : ");
        double secondNumber = Convert.ToDouble(Console.ReadLine());

        double result = Calculate(operation, firstNumber, secondNumber);
        Console.WriteLine($"Result: {result}");

    }
    static double Calculate(string operation, double a, double b)
    {
        switch (operation)
        {
            case "add":
                return a + b;
            case "sub":
                return a - b;
            case "mul":
                return a * b;
            case "div":
                return a / b;
            default:
                throw new ArgumentException("Invalid operation");
        }
    }
}