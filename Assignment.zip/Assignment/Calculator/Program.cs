﻿//using System;

//class Program
//{
//    static void Main(string[] args)
//    {
//        Console.WriteLine("Enter the operation : ");
//        string operation = Console.ReadLine().ToLower();

//        Console.Write("Enter the first number : ");
//        double firstNumber = Convert.ToDouble(Console.ReadLine());

//        Console.Write("Enter the second number : ");
//        double secondNumber = Convert.ToDouble(Console.ReadLine());

//        double result = Calculate(operation, firstNumber, secondNumber);
//        Console.WriteLine($"Result: {result}");

//    }
//    static double Calculate(string operation, double a, double b)
//    {
//        switch (operation)
//        {
//            case "add":
//                return a + b;
//            case "sub":
//                return a - b;
//            case "mul":
//                return a * b;
//            case "div":
//                return a / b;
//            default:
//                throw new ArgumentException("Invalid operation");
//        }
//    }
//}


using System;
namespace Calculate
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Press 1 for Addition:");
            Console.WriteLine("Press 2 for Subtraction:");
            Console.WriteLine("Press 3 for Multiplication:");
            Console.WriteLine("Press 4 for Division:");
            int choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    {
                        Console.WriteLine("Press 1 for Addition of 2 numbers:");
                        Console.WriteLine("Press 2 for Addition of 3 numbers:");
                        int add = Convert.ToInt32(Console.ReadLine());
                        switch (add)
                        {
                            case 1:
                                {
                                    Console.WriteLine("Enter 2 Numbers for Addition:");
                                    int a = Convert.ToInt32(Console.ReadLine());
                                    int b = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine($"{a} + {b} = {a + b}");
                                }
                                break;
                            case 2:
                                {
                                    Console.WriteLine("Enter 3 Numbers for Addition:");
                                    int a = Convert.ToInt32(Console.ReadLine());
                                    int b = Convert.ToInt32(Console.ReadLine());
                                    int c = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine($"{a} + {b} + {c} = {a + b + c}");
                                }
                                break;
                            default:
                                Console.WriteLine("Invalid Number");
                                break;
                        }
                    }
                    break;
                case 2:
                    {
                        Console.WriteLine("Press 1 for subtraction of 2 numbers");
                        Console.WriteLine("Press 2 for subtraction of 3 numbers");
                        int sub = Convert.ToInt32(Console.ReadLine());
                        switch (sub)
                        {
                            case 1:
                                {
                                    Console.WriteLine("Enter 2 numbers for subtraction");
                                    int a = Convert.ToInt32(Console.ReadLine());
                                    int b = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine($"{a} - {b} = {a - b}");
                                    break;
                                }
                            case 2:
                                {
                                    Console.WriteLine("Enter 3 numbers for subtraction");
                                    int a = Convert.ToInt32(Console.ReadLine());
                                    int b = Convert.ToInt32(Console.ReadLine());
                                    int c = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine($"{a} - {b} - {c} = {a - b - c}");
                                    break;
                                }
                            default:
                                Console.WriteLine("Invalid Number");
                                break;
                        }
                    }
                    break;
                case 3:
                    Console.WriteLine("Press 1 for multiplication of 2 numbers");
                    Console.WriteLine("Press 2 for multiplication of 3 numbers");
                    int mul = Convert.ToInt32(Console.ReadLine());
                    switch (mul)
                    {
                        case 1:
                            {
                                Console.WriteLine("Enter 2 numbers for multiplication");
                                int a = Convert.ToInt32(Console.ReadLine());
                                int b = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine($"{a} * {b} = {a * b}");
                                break;
                            }
                        case 2:
                            {
                                Console.WriteLine("Enter 3 numbers for multiplication");
                                int a = Convert.ToInt32(Console.ReadLine());
                                int b = Convert.ToInt32(Console.ReadLine());
                                int c = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine($"{a} * {b} * {c} = {a * b * c}");
                                break;
                            }
                        default:
                            Console.WriteLine("Invalid Number");
                            break;
                    }
                    break;
                case 4:
                    {
                        Console.WriteLine("Enter 2 Numbers for Division:");
                        int a = Convert.ToInt32(Console.ReadLine());
                        int b = Convert.ToInt32(Console.ReadLine());
                        if (b != 0)
                        {
                            Console.WriteLine($"{a} / {b} = {(double)a / b}");
                        }
                        else
                        {
                            Console.WriteLine("Cann't divide by zero!");
                        }
                    }
                    break;
                default:
                    Console.WriteLine("Invalid Number");
                    break;
            }
        }
    }
}
