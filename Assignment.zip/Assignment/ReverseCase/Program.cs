﻿using System;

namespace ReverseCase
{
    class Reverse
    {
        public static String ReverseCase(string input)
        {
            String result = " ";
            for (int i = 0; i < input.Length; i++)
            {
                char c = input[i];
                if (char.IsLower(c))
                {
                    result += char.ToUpper(c);
                }
                else if (char.IsUpper(c))
                {
                    result += char.ToLower(c);
                }
                else
                {
                    result += c;
                }
            }
            return result;
        }
        static void Main(String[] args)
        {
            Console.Write("Enter String : ");
            string input = Console.ReadLine();

            string result = ReverseCase(input);
            Console.WriteLine(result);
        }
    }
}


