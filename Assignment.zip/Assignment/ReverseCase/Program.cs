﻿using System;

namespace ReverseCase
{
    class Reverse
    {
        public static String ReverseCase(string input)
        {
            String result = " ";
            foreach (char c in input)
            {
                if (char.IsLower(c)) 
                    result += char.ToUpper(c);
                else if (char.IsUpper(c))
                    result += char.ToLower(c);
                else
                    result += c;
            }
            return result;
        }
        public static String ReverseCaseUpperToLower(string input)
        {
            String result = " ";
            for (int i = 0; i < input.Length; i++)
            {
                if (input[i] >= 'a' && input[i] <= 'z')
                    result += (char)(input[i] - 32);
                else if (input[i] >= 'A' && input[i] <= 'Z')
                    result += (char)(input[i] + 32);
                else
                    result += input[i];
            }
            return result;
        }
        static void Main(String[] args)
        {
            Console.Write("Enter String : ");
            string input = Console.ReadLine();

            string result = ReverseCaseUpperToLower(input);
            Console.WriteLine(result);
        }
    }
}


