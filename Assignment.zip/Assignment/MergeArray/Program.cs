﻿using System;

namespace MergeArray
{
    class Program
    {
        static int[] Merge(int[] a, int[] b)
        {
            int[] c = new int[a.Length + b.Length];
            for (int i = 0; i < a.Length; i++)
            {
                c[i] = a[i];
            }

            for (int i = 0; i < b.Length; i++)
            {
                c[a.Length + i] = b[i];
            }

            return c;
        }
        static void Main(string[] args)
        {
            int[] arr = {2,9};
            int[] arr1 = {1,9,7,3};
            int[] arr2 = Merge(arr, arr1);

            Console.WriteLine("Merged Array:");
            for (int i = 0; i < arr2.Length; i++)
            {
                Console.Write(arr2[i] + " ");
            }
        }
    }
}
