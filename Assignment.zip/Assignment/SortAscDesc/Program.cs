﻿using System;

namespace SortAscDesc
{
    class Program
    {
        static void Main()
        {
            Console.Write("Enter a number : ");
            string input = Console.ReadLine();

            if (int.TryParse(input, out int number))
            {
                Console.Write("Enter Sorting order : ");
                string order = Console.ReadLine().ToLower();
                string result = sortDigits(number, order);
                Console.WriteLine($"Sorted result: {result}");
            }
            else
            {
                Console.WriteLine("Invalid input!!");
            }
        }

        static string sortDigits(int number, string order)
        {
            string numberString = Math.Abs(number).ToString();

            char[] digits = new char[numberString.Length];
            for (int i = 0; i < numberString.Length; i++)
            {
                digits[i] = numberString[i];
            }

            for (int i = 0; i < digits.Length; i++)
            {
                for (int j = i + 1; j < digits.Length; j++)
                {
                    if (order == "asc" && digits[i] > digits[j])
                    {
                        char temp = digits[i];
                        digits[i] = digits[j];
                        digits[j] = temp;
                    }
                    else if (order == "desc" && digits[i] < digits[j])
                    {
                        char temp = digits[i];
                        digits[i] = digits[j];
                        digits[j] = temp;
                    }
                }
            }
            return new string(digits);
        }

        static string sortingDigits(int number, string order)
        {
            char[] digits = Math.Abs(number).ToString().ToCharArray();
            if (order == "asc")
            {
                Array.Sort(digits);
            }
            else if (order == "desc")
            {
                Array.Sort(digits);
                Array.Reverse(digits);
            }
            else
            {
                return "Invalid order";
            }
            return new string(digits);
        }
    }
}