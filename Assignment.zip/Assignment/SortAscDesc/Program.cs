﻿using System;
class Program
{
    static void Main()
    {
        Console.Write("Enter a number: ");
        string input = Console.ReadLine();
        if (int.TryParse(input, out int number))
        {
            Console.Write("Enter Sorting order : ");
            string order = Console.ReadLine().ToLower();
            string result = SortDigits(number, order);
            Console.WriteLine($"Sorted result : {result}");
        }
        else
        {
            Console.WriteLine("Invalid input!!");
        }
    }
    static string SortDigits(int number, string order)
    {
        char[] digits = Math.Abs(number).ToString().ToCharArray();
        if (order == "asc")
        {
            Array.Sort(digits);
        }
        else if (order == "desc")
        {
            Array.Sort(digits);
            Array.Reverse(digits);
        }
        else
        {
            return "Invalid order";
        }
        return new string(digits);
    }
}