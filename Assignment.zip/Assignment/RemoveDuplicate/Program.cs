﻿using System;
using System.Linq;

namespace RemoveDuplicate
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a String : ");
            string remove = Console.ReadLine();

            string result = "";
            for (int i = 0; i < remove.Length; i++)
            {
                if (!result.Contains(remove[i]))
                    result += remove[i];
            }

            Console.WriteLine("Updated String : "+result);
        }

        public static string RemoveDuplicateChar(string s)
        {
            char[] arr = s.ToCharArray();
            int index = 0;

            for (int i = 0; i < arr.Length; i++)
            {
                int j; 
                for (j = 0 ; j < i; j++)
                {
                    if (arr[i] == arr[j])
                        break;
                }

                if (j == i)
                    arr[index++] = arr[i];
            }
            return new string(arr,0,index);
        }
    }
}