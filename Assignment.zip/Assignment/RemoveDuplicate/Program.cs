﻿using System;
using System.Linq;

namespace RemoveDuplicate
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a String : ");
            string remove = Console.ReadLine();

            string result = "";
            for (int i = 0; i < remove.Length; i++)
            {
                if (!result.Contains(remove[i]))
                    result += remove[i];
            }
            Console.WriteLine(result);
        }
    }
}