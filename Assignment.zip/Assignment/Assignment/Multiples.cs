﻿using System;

namespace ArrayOfMultiples
{
    class Multiples
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the Number : ");
            int num = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter the Length : ");
            int length = Convert.ToInt32(Console.ReadLine());

            int[] result = new int[length];


            for (int i = 0; i < result.Length; i++)
            {
                result[i] = num * (i+1);
            }

            foreach (var item in result)
            {
                Console.Write($"{item} ");
            }
        }
    }
}
