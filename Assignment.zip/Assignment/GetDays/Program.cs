﻿using System;

namespace GetDays
{
    class DaysCount
    {
        static void Main(string[] args)
        {
            DateTime startDate = new DateTime(2024, 11, 12);
            DateTime endDate = new DateTime(2024, 11, 18);

            TimeSpan duration = endDate - startDate;
            Console.WriteLine(duration.Days);
        }
    }
}