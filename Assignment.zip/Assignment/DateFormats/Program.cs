﻿using System;

namespace DateFormat
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTime curDate = DateTime.Now;
            Console.WriteLine("Current Date : " + curDate);
            Console.WriteLine();
            Console.WriteLine(curDate.ToString("dd/MM/yyyy"));
            Console.WriteLine(curDate.ToString("dd-MMM-yyyy"));
            Console.WriteLine(curDate.ToString("MM/dd/yyyy"));
            Console.WriteLine(curDate.ToString("yyyy-MM-dd"));
            Console.WriteLine(curDate.ToString("dd/MM/yyyy hh:mm:ss"));
            Console.WriteLine(curDate.ToString("dd/MM/yyyy hh:mm:ss tt"));
        }
    }
}
