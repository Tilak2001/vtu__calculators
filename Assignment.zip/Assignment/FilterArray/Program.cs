﻿using System;
using System.Collections.Generic;

namespace FilterArray
{
    class Program
    {
        static void Main()
        {
            Console.Write("Enter elements : ");
            string input = Console.ReadLine();
            string[] inputArray = input.Split(',');

            var result = FilterArray(inputArray);
            Console.WriteLine("Filtered array : " + string.Join(", ", result));
        }
        static List<int> FilterArray(string[] inputArray)
        {
            List<int> filteredList = new List<int>();
            foreach (var item in inputArray)
            {
                string trimmedItem = item.Trim();
                if (int.TryParse(trimmedItem, out int number))
                {
                    if (number >= 0)
                    {
                        filteredList.Add(number);
                    }
                }
            }
            return filteredList;
        }
    }
}
