﻿using System;
using System.Linq;

namespace CountRecord
{
    class Program
    {
        static void Main(string[] args)
        {
            var totalCount = 0;
            Console.Write("Enter the number of elements : ");
            int input = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the elements : ");
            int[] arr = new int[input];

            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());
                totalCount++;
            }

            Console.WriteLine("Total count of elements : "+ totalCount);
        }
        static int Count()
        {
            var totalCount = 0;
            int[] arr = {10,5,5,2,8,4,2,1};

            totalCount = arr.Count();
            Console.WriteLine(totalCount);

            return totalCount;
        }
    }
}