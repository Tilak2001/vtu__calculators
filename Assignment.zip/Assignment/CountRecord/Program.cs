﻿using System;
using System.Linq;

namespace CountRecord
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var totalCount = 0;
            int[] arr = {10,5,5,2,8,4};

            totalCount = arr.Count();
            Console.WriteLine(totalCount);
        }
    }
}