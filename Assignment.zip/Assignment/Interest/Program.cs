﻿using System;

namespace Interest
{
    class SimpleInterest
    {
        public static double Calculate(double principle, double term, double rate)
        {
            return (principle * term * rate) / 100;
        }
        static void Main(string[] args)
        {
            Console.Write("Enter the Principle : ");
            double principle = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter the Term : ");
            double term = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter the Rate of Interest : ");
            double rate = Convert.ToDouble(Console.ReadLine());

            double interest = Calculate(principle, term, rate);
            Console.WriteLine(interest);
        }
    }
}
