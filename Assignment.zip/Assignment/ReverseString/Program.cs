﻿using System;

namespace ReverseString
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a String : ");
            string input = Console.ReadLine();

            string Reverse = "";
            for (int i = 0; i < input.Length; i++)
            {
                Reverse = input[i] + Reverse;
            }

            Console.WriteLine(input.Length);
            Console.WriteLine(Reverse.Length);

            String.Concat(input,Reverse);

            Console.WriteLine("Reversed String: " + Reverse);
        }
    }
}


