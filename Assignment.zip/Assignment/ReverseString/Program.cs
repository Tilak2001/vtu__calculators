﻿using System;
using System.Linq;

namespace ReverseString
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a String : ");
            String input = Console.ReadLine();
            //Console.WriteLine(input.Reverse);
            string Reverse = "";
            string replaceString = "goutham p";
            replaceString.Replace('o', '0');


            for (int i = 0; i < input.Length; i++)
            {
                Reverse = input[i] + Reverse;
            }

            Console.WriteLine(input.Length);
            Console.WriteLine(Reverse.Length);
            //for (int i = input.Length - 1; i >= 0; i--)
            //{
            //    Reverse += input[i];
            //}

            Console.Write("Reversed String :" + Reverse);

        }
    }
}