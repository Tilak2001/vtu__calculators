﻿using System;

namespace FormatNumber
{
    class Program
    {
        public static string Format(int number)
        {
            return number.ToString("0,0"); 
        }
        static void Main(string[] args)
        {
            Console.Write("Enter a Number : ");
            string input = Console.ReadLine();

            if (int.TryParse(input, out int number))
            {
                string FormattedNo = Format(number);
                Console.WriteLine("Formatted Number : "+FormattedNo);
            }
            else
            {
                Console.WriteLine("Invalid Number");
            }
        }
    }
}

