  // $(document).ready(function() {
//   let $carouselItems = $('.item');
//   let $indicators = $('.indicators button');
//   let currentIndex = 0;
//   let slideInterval;

//   // Function to show the slide based on the index
//   function showSlide(index) {
//     $carouselItems.removeClass('active');  // Remove 'active' from all slides
//     $indicators.removeClass('active');  // Remove 'active' from all indicators

//     // Fade in the current slide and show the active indicator
//     $carouselItems.eq(index).addClass('active');
//     $indicators.eq(index).addClass('active');
//   }

//   // Indicator click event
//   $indicators.on('click', function() {
//     currentIndex = $(this).data('slide-to');
//     showSlide(currentIndex);
//   });

//   // Auto slide functionality
//   function nextSlide() {
//     currentIndex = (currentIndex + 1) % $carouselItems.length;
//     showSlide(currentIndex);
//   }

//   // Set interval for automatic slide change every 5 seconds
//   slideInterval = setInterval(nextSlide, 5000);

//   // Pause the auto slide when hovering over the carousel
//   $('.carousel').hover(function() {
//     clearInterval(slideInterval);
//   }, function() {
//     slideInterval = setInterval(nextSlide, 5000);
//   });

//   // Show the initial slide
//   showSlide(currentIndex);
// });



$(document).ready(function() {
  let $carouselItems = $('.text-wrapper'); 
  let $indicators = $('.indicators button');
  let currentIndex = 0;
  let slideInterval;


  function showSlide(index) {
  
    $carouselItems.removeClass('active');
    $indicators.removeClass('active');

    
    $carouselItems.eq(index).addClass('active');
    $indicators.eq(index).addClass('active');

  
    $('.inner').css('transform', 'translateX(' + (-index * 100) + '%)');
  }


  $indicators.on('click', function() {
    currentIndex = $(this).data('slide-to');
    showSlide(currentIndex);
  });


  function nextSlide() {
    currentIndex = (currentIndex + 1) % $carouselItems.length;
    showSlide(currentIndex);
  }

  slideInterval = setInterval(nextSlide, 5000);

  $('.carousel').hover(function() {
    clearInterval(slideInterval);
  }, function() {
    slideInterval = setInterval(nextSlide, 5000);
  });

  showSlide(currentIndex);
});


// $(document).ready(function() {
//   // Create an IntersectionObserver instance to detect when the '.vis' element is in view
//   const observer = new IntersectionObserver((entries, observer) => {
//     entries.forEach(entry => {
//       // The 'vis' element is inside 'entry.target'
//       const visionText = entry.target;
      
//       // Check if the element is in view
//       if (entry.isIntersecting) {
//         // Add the class that triggers the underline animation
//         $(visionText).addClass('underline-animate');
//       }
//     });
//   }, {
//     threshold: 0.5  // Trigger when 50% of the element is in view
//   });

//   // Observe all '.vis' elements (the word "VISION")
//   $('.vis').each(function() {
//     observer.observe(this);  // Observe each 'VISION' word
//   });
// });

